<?php

// Exit if accessed directly
if( ! defined( 'ABSPATH' ) ) exit;

// This template is made to return an empty string
echo '';