<?php
/**
 * This will overwrite the default bbPress User Login form and will display the Profile Builder Login form
 */

echo do_shortcode('[wppb-login]');